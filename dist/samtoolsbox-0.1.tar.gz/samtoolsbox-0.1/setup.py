from setuptools import setup, find_packages

setup(
    name='samtoolsbox',
    version=0.1,
    description=(
        'sam\'s tools box'
    ),
    #long_description=open('README.rst').read(),
    author='sam',
    author_email='1102566608@qq.com',
    license='BSD License',
    packages=find_packages(),
    platforms=["all"],
    url='http://b.isam.top/',
)