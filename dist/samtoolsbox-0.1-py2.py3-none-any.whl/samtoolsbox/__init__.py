def hello_sam():
    print(114514)